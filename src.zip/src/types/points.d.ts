export type PointWithUpdate = THREE.Mesh & {
    update: () => void;
  };