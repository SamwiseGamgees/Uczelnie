import { useState } from 'react';
import supabase from '../../config/supabaseClient';
import { useNavigate } from 'react-router-dom';
import './ForgotPassword.css';

// Twoja ikona SVG jako komponent
function LockIcon() {
  return (
    <svg
      viewBox="0 0 58.98 58.98"
      xmlns="http://www.w3.org/2000/svg"
      fill="#e50914"
      className="lock-icon"
    >
      <path d="M35.35 24.95h-.28v-3.71c0-2.76-2.51-5-5.58-5-3.08 0-5.58 2.24-5.58 5 0 .42.34.76.77.76a.76.76 0 0 0 .76-.76c0-1.91 1.82-3.47 4.05-3.47s4.04 1.56 4.04 3.47v3.71h-10.2c-1.71 0-3.11 1.49-3.11 3.31v8.67c0 1.82 1.49 3.31 3.32 3.31h11.89c1.83 0 3.32-1.49 3.32-3.31v-8.67c0-1.82-1.49-3.31-3.4-3.31zm1.87 11.98c0 .98-.8 1.78-1.79 1.78H23.54c-.98 0-1.78-.8-1.78-1.78v-8.67c0-.98.71-1.78 1.57-1.78h12.1c.99 0 1.79.8 1.79 1.78v8.67zm-5.98-3.03c0 .97-.79 1.75-1.75 1.75a1.746 1.746 0 1 1 0-3.49 1.75 1.75 0 0 1 1.75 1.74zm-1.75 25.08C13.23 58.98 0 45.76 0 29.49 0 13.23 13.23 0 29.49 0s29.49 13.23 29.49 29.49c0 16.27-13.23 29.49-29.49 29.49zm0-57.4C14.1 1.58 1.57 14.1 1.57 29.49c0 15.4 12.53 27.92 27.92 27.92S57.4 44.89 57.4 29.49c0-15.39-12.52-27.91-27.91-27.91z" />
    </svg>
  );
}

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);
    setError(null);
    setIsSubmitting(true);

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: 'http://localhost:5174/reset',
    });

    if (error) {
      setError('Nie udało się wysłać maila: ' + error.message);
    } else {
      navigate('/check-email');
    }

    setIsSubmitting(false);
  };

  return (
    <div className="container active">
      <div className="mini-form">
        <div className="header">
          <LockIcon />
          <div className="text_l">Nie pamiętasz hasła?</div>
          <div className="description">
            W poniższe pole wpisz adres e-mail podany podczas rejestracji konta
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="inputs">
            <div className="input">
              <input
                type="email"
                placeholder="E-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          {error && <div className="error-message">{error}</div>}
          {message && (
            <div className="error-message" style={{ color: '#4caf50' }}>
              {message}
            </div>
          )}

          <div className="button-group">
            <button
              type="button"
              className="cancel-button"
              onClick={() => navigate('/')}
            >
              Anuluj
            </button>
            <button type="submit" className="submit_l" disabled={isSubmitting}>
              {isSubmitting ? 'Wysyłam...' : 'Dalej'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
