import React from "react";
import "./NotFound.css";

export default function NotFound() {
  return (
    <div className="notfound-container">
      404
    </div>
  );
}
